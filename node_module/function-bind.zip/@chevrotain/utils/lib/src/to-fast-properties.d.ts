export declare function toFastProperties(toBecomeFast: any): any;
