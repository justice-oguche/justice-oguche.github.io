import {
  require_client
} from "./chunk-ZK6T5TI4.js";
import "./chunk-ZGRSIX2Q.js";
import "./chunk-ROME4SDB.js";
export default require_client();
//# sourceMappingURL=react-dom_client.js.map
