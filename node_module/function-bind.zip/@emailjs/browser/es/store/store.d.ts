interface Store {
    _userID?: string;
    _origin: string;
}
export declare const store: Store;
export {};
