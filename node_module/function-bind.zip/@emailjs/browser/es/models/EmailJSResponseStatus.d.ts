export declare class EmailJSResponseStatus {
    status: number;
    text: string;
    constructor(httpResponse: XMLHttpRequest | null);
}
