export declare const validateParams: (publicKey?: string, serviceID?: string, templateID?: string) => boolean;
