import * as React from 'react';
declare type HudProps = {
    children: React.ReactNode;
    renderPriority?: number;
};
export declare function Hud({ children, renderPriority }: HudProps): JSX.Element;
export {};
