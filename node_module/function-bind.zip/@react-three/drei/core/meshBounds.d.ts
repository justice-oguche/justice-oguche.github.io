import { Raycaster, Intersection } from 'three';
export declare function meshBounds(raycaster: Raycaster, intersects: Intersection[]): void;
