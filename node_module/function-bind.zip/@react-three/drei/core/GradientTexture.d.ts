/// <reference types="react" />
declare type Props = {
    stops: Array<number>;
    colors: Array<string>;
    attach?: string;
    size?: number;
} & JSX.IntrinsicElements['texture'];
export declare function GradientTexture({ stops, colors, size, ...props }: Props): JSX.Element;
export {};
