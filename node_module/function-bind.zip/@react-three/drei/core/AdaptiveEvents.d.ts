export declare function AdaptiveEvents(): null;
